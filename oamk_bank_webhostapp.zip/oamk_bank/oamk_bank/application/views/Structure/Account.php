



<?php

$this->load->view('Templates/Header_inside') ;

$this->load->view($body) ;

$this->load->view('Templates/Footer_inside') ;

?>
