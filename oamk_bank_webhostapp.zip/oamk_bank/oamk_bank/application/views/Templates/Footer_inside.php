
<!-- <hr>Here is footer -->

<div class="clock_test" id="current_time"></div>
</body>
</html>
