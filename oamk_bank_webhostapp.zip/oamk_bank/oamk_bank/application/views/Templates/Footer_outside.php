<!-- Footer Section -->
<div class="footer" style="background-color :#FF9400">
  <div class="footcontain">
    <div>
      <div class="copy"><small> Copyright &copy; 2018 Oamk Bank Oyj</small></div>
      <div class="oamkfooter" style="color:#ffffff">Oamk Bank Oyj</div>
      <div class="foot-text" style="color : #ffffff"> simple, fair and fast</div>
    </div>
    <div class="contactfoot">
      <h3>Contact information</h3>
      <p>Kotkantie 1<br/>
      90250 Oulu<br/>
    FINLAND<br/>

    <br/>
    Tel: 040 1000 0000<br/>
    email: bank@oamkbank.gq
  </p><br/>
    </div>
<!-- SoMe Icon Section -->
    <div class="somefooter">
      <a href="https://www.facebook.com/oamkbank"><img style="margin-right: 20px;" src="<?php echo base_url('img/fb.png');?>" alt="" target="_blank">
      <a href="https://plus.google.com/+oamkbank"><img style="margin-right: 20px;" src="<?php echo base_url('img/gplus.png');?>" alt="" target="_blank">
      <a href="http://www.twitter.com/oamkbank"><img style="margin-right: 20px;" src="<?php echo base_url('img/tw.png');?>" alt="" target="_blank">
      <a href="http://www.instagram.com/oamkbank"><img style="margin-right: 20px;" src="<?php echo base_url('img/ig.png');?>" alt="" target="_blank">
    </div>
    <br/>
  </div>
  </div>
<!-- </div> -->
</div>


</body>
</html>
