
    <div class="nav-bar">
      <div id="nav-container">
          <a href="http://www.oamkbank.gq">
            <img class="logo" src="img/oamkb-logo-transp.png"/></a>
        <ul>
          <li><a href="openAcct.html">OPEN ACCOUNT</a></li>
          <li><a href="everyBank.html">EVERYDAY BANKING</a></li>
          <li><a href="loan.html">LOANS</a></li>
          <li><a href="about.html">ABOUT</a></li>
          <li><a href="contact.html">CONTACT</a></li>
        </ul>
        <div class="divlogin-btn">
          <input type="button" class="login-btn" name="" value="LOGIN">
        </div>
      </div>
    </div>
    
    <!-- First Section -->
   
        
    </div>
    <div class="btnonabtcontainer">
      <a href="/everyBank.html" class="btn">OUR SERVICES</a>
    </div>
    <div class="btnonabtoa">
      <a href="/openAcct.html" class="btnoa">OPEN ACCOUNT</a>
    </div>



    
    <button onclick="topFunction()" id="Bttop" title="Go to top">Top</button>
    <!-- Footer Section -->
      <div class="footer" style="background-color :#FF9400">
          <div class="footcontain">
            <div>
              <div class="copy"><small> Copyright &copy; 2018 Oamk Bank Oyj</small></div>
              <div class="oamkfooter" style="color:#ffffff">Oamk Bank Oyj</div>
              <div class="foot-text" style="color : #ffffff"> simple, fair and fast</div>
            </div>
            <div class="contactfoot">
              <h3>Contact information</h3>
              <p>Kotkantie 1<br/>
              90250 Oulu<br/>
            FINLAND<br/>
  
            <br/>
            Tel: 040 1000 0000<br/>
            email: bank@oamkbank.gq
          </p><br/>
        <!-- SoMe Icon Section -->    
            </div>
            <div class="somefooter">
              <a href="https://www.facebook.com/oamkbank"><img style="margin-right: 20px;" src="img/fb.png" alt="" target="_blank">
              <a href="https://plus.google.com/+oamkbank"><img style="margin-right: 20px;" src="img/gplus.png" alt="" target="_blank">
              <a href="http://www.twitter.com/oamkbank"><img style="margin-right: 20px;" src="img/tw.png" alt="" target="_blank">
              <a href="http://www.instagram.com/oamkbank"><img style="margin-right: 20px;" src="img/ig.png" alt="" target="_blank">
            </div> 
            <br/>
          </div>
          </div>
      </div>
      
    </div>
