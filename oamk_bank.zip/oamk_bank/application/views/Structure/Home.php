



<?php

$this->load->view('Templates/Header_outside') ;

$this->load->view($body) ;

$this->load->view('Templates/Footer_outside') ;

?>
