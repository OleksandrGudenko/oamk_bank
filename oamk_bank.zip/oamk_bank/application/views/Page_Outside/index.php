



    <!-- First Section -->
    <div class="top-banner">
          <img src="<?php echo base_url('img/home-temp-trans.png');?>" alt="" class="guy-bg" >
          <h1 class="tophead">Together, <br /> financial freedom</h1>
          <p class="midhead">simple, fair and fast</p>
          <a href="<?php echo site_url('Page_Controller/openAcct');?>">
          <input type="button" class="openact" name="" value="OPEN ACCOUNT">
          </a>
      </div>
    <!-- Middle Section -->
      <div class="mid-banner">
        <div class="mid-wrap">
          <h1 class="sumcenter-title" >As an online bank without any branch, all our savings are passed to you.
                Get more for your money with our services.</h1>
        </div>
        <hr>
      <div class="mid-row">
        <div class="topleft"> <img src="<?php echo base_url('img/money.png');?>" alt="">
          <h3 style="color: #f2882f"><strong>FAIR RATES</strong></h3>
            <p> You get competitive rates because we are an online bank so we don't spend on branches.
              All our services are automated to benefit you - our customer.</p>
        </div>
      <div class="topright"> <img src="<?php echo base_url('img/team.png');?>" alt="">
          <h3 style="color: #f2882f"><strong>EXPERIENCE</strong></h3>
            <p> Swift financial services are guaranteed  with our highly qualified team of over 20 years
              in the banking industry and access to world's top financial markets.</p>
        </div>
      <div class="row">
        <div class="bottomright"> <img src="<?php echo base_url('img/safebox.png');?>" alt="">
          <h3 style="color: #f2882f"><strong>SECURE BANKING</strong></h3>
            <p> All your account information and funds are insured. Data transactions within any of our channels are AES-256 encrypted.
              2-Step Verification on all account.</p>
        </div>
          <div class="bottomleft"> <img src="<?php echo base_url('img/monitor2.png');?>" alt="">
            <h3 style="color: #f2882f"><strong>TECHNOLOGY</strong></h3>
              <p> OAMK Bank provides modern banking by using recent technologies to bring huge savings
                to our customers. Our online bank give you clutter-free banking experience.</p>
          </div>
        </div>
      </div>
      </div>
      <button onclick="topFunction()" id="Bttop" title="Go to top">Top</button>
  
